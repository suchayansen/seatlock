# Bahra University — Event Booking Portal (Login Landing Page)

React + Vite + plain CSS + Lucide icons.

## Run

```bash
npm install
npm run dev
```

Production build: `npm run build` then `npm run preview`.

## Assets you need to add

The page is built to use your real assets. Drop them in `public/images/`:

| File | Purpose |
| --- | --- |
| `public/images/campus.jpg` | Full-screen photograph of the Bahra campus (buildings on the hillside, mountains, mist, pines). Use a wide, high-resolution image (about 2400px or wider). |
| `public/images/logo.png` | Official Bahra University logo (transparent PNG, light-on-dark works best). |

Until they exist, the page shows a misty-mountain gradient fallback and a typographic recreation of the wordmark. No code changes are needed once the files are added.

The screenshot itself is deliberately not used as a background.

## Structure

```
src/
  components/
    UniversityBrand.jsx   logo (image with typographic fallback)
    TopNavigation.jsx     Event Booking Portal | Back to Website
    HeroSection.jsx       pill, heading, description, accent line
    EventCategories.jsx   four icon + label categories
    LoginCard.jsx         glass login card
    FooterInfo.jsx        motto, line, location
  styles/
    global.css            tokens, reset, focus styles
    login.css             layout, components, responsive rules
  App.jsx
  main.jsx
```

## Notes

- Authentication is not connected. Submitting the form does nothing, and no success state is shown.
- "Continue with Google" is a UI placeholder until OAuth is added.
- "Back to Website" points to `https://www.bahrauniversity.edu.in`; change it in `TopNavigation.jsx` if needed.
- Animation is limited to a gentle fade/rise on load and button hover transitions, and respects `prefers-reduced-motion`.
