import UniversityBrand from './components/UniversityBrand.jsx'
import TopNavigation from './components/TopNavigation.jsx'
import HeroSection from './components/HeroSection.jsx'
import LoginCard from './components/LoginCard.jsx'
import FooterInfo from './components/FooterInfo.jsx'

export default function App() {
  return (
    <div className="page">
      <div className="page__bg" aria-hidden="true" />
      <div className="page__shade" aria-hidden="true" />
      <div className="page__slash" aria-hidden="true" />

      <header className="page__header">
        <UniversityBrand />
        <TopNavigation />
      </header>

      <main className="page__main">
        <HeroSection />
        <LoginCard />
      </main>

      <FooterInfo />
    </div>
  )
}
