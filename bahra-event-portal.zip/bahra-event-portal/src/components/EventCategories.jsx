import { Users, Mic, CalendarDays, Trophy } from 'lucide-react'

const categories = [
  { label: 'Workshops', Icon: Users },
  { label: 'Seminars', Icon: Mic },
  { label: 'Cultural Events', Icon: CalendarDays },
  { label: 'Competitions', Icon: Trophy },
]

export default function EventCategories() {
  return (
    <ul className="categories" aria-label="Event categories">
      {categories.map(({ label, Icon }) => (
        <li className="categories__item" key={label}>
          <Icon size={20} strokeWidth={1.25} aria-hidden="true" />
          <span>{label}</span>
        </li>
      ))}
    </ul>
  )
}
