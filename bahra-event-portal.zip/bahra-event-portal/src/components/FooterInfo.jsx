import { MapPin } from 'lucide-react'

export default function FooterInfo() {
  return (
    <footer className="footer">
      <p className="footer__motto">
        <span>Learn</span>
        <i aria-hidden="true">·</i>
        <span>Participate</span>
        <i aria-hidden="true">·</i>
        <span>Grow</span>
      </p>
      <span className="footer__line" aria-hidden="true" />
      <p className="footer__loc">
        <MapPin size={14} strokeWidth={1.5} aria-hidden="true" />
        <span>Solan, Himachal Pradesh, India</span>
      </p>
    </footer>
  )
}
