import EventCategories from './EventCategories.jsx'

export default function HeroSection() {
  return (
    <section className="hero" aria-labelledby="hero-title">
      <p className="hero__pill">
        <span>Events</span>
        <i aria-hidden="true">•</i>
        <span>Seminars</span>
        <i aria-hidden="true">•</i>
        <span>Workshops</span>
      </p>

      <h1 className="hero__title" id="hero-title">
        Book Your
        <br />
        Next <em>Event</em>
        <span className="sr-only">.</span>
      </h1>

      <p className="hero__desc">
        Explore and register for upcoming events
        <br />
        at Bahra University.
      </p>

      <span className="hero__rule" aria-hidden="true" />

      <EventCategories />
    </section>
  )
}
