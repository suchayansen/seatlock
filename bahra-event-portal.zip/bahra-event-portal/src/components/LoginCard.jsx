import { useState } from 'react'
import { CalendarCheck, User, Lock, Eye, EyeOff, ArrowRight } from 'lucide-react'

const ROLES = [
  { id: 'student', label: 'Student', placeholder: 'Student ID / Email' },
  { id: 'admin', label: 'Admin', placeholder: 'Admin Email' },
  { id: 'organiser', label: 'Organiser', placeholder: 'Organiser Email' },
]

function GoogleLogo() {
  return (
    <svg width="18" height="18" viewBox="0 0 48 48" aria-hidden="true">
      <path fill="#EA4335" d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z" />
      <path fill="#4285F4" d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z" />
      <path fill="#FBBC05" d="M10.53 28.59c-.48-1.45-.76-2.99-.76-4.59s.27-3.14.76-4.59l-7.98-6.19C.92 16.46 0 20.12 0 24c0 3.88.92 7.54 2.56 10.78l7.97-6.19z" />
      <path fill="#34A853" d="M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.15 1.45-4.92 2.3-8.16 2.3-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z" />
    </svg>
  )
}

export default function LoginCard() {
  const [role, setRole] = useState('student')
  const [identifier, setIdentifier] = useState('')
  const [password, setPassword] = useState('')
  const [showPassword, setShowPassword] = useState(false)

  const activeRole = ROLES.find((r) => r.id === role)

  // Authentication is intentionally not connected yet.
  const handleSubmit = (e) => {
    e.preventDefault()
    // later: send { role, identifier, password } to your API
  }

  return (
    <section className="card" aria-labelledby="login-title">
      <CalendarCheck className="card__icon" size={34} strokeWidth={1.5} aria-hidden="true" />
      <h2 className="card__title" id="login-title">Event Booking Login</h2>
      <p className="card__sub">Access your account to book events</p>

      <div className="roles" role="tablist" aria-label="Login as">
        {ROLES.map((r) => (
          <button
            key={r.id}
            type="button"
            role="tab"
            aria-selected={role === r.id}
            className={`roles__tab ${role === r.id ? 'is-active' : ''}`}
            onClick={() => setRole(r.id)}
          >
            {r.label}
          </button>
        ))}
      </div>

      <form className="card__form" onSubmit={handleSubmit} noValidate>
        <label className="field">
          <span className="sr-only">{activeRole.placeholder}</span>
          <User className="field__icon" size={16} strokeWidth={2} aria-hidden="true" />
          <input
            className="field__input"
            type="text"
            name="identifier"
            placeholder={activeRole.placeholder}
            autoComplete="username"
            value={identifier}
            onChange={(e) => setIdentifier(e.target.value)}
          />
        </label>

        <label className="field">
          <span className="sr-only">Password</span>
          <Lock className="field__icon" size={16} strokeWidth={2} aria-hidden="true" />
          <input
            className="field__input"
            type={showPassword ? 'text' : 'password'}
            name="password"
            placeholder="Password"
            autoComplete="current-password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />
          <button
            type="button"
            className="field__toggle"
            onClick={() => setShowPassword((v) => !v)}
            aria-label={showPassword ? 'Hide password' : 'Show password'}
            aria-pressed={showPassword}
          >
            {showPassword ? <Eye size={16} strokeWidth={1.75} /> : <EyeOff size={16} strokeWidth={1.75} />}
          </button>
        </label>

        <button type="submit" className="btn btn--primary">
          <span>Login</span>
          <ArrowRight size={15} strokeWidth={1.75} aria-hidden="true" />
        </button>

        <div className="card__or" role="separator" aria-label="or">
          <span>or</span>
        </div>

        {/* UI placeholder until real Google OAuth is integrated */}
        <button type="button" className="btn btn--ghost">
          <GoogleLogo />
          <span>Continue with Google</span>
        </button>

        <a className="card__forgot" href="#forgot-password">Forgot Password?</a>
      </form>
    </section>
  )
}