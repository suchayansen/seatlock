import { CalendarDays, ArrowRight } from 'lucide-react'

export default function TopNavigation() {
  return (
    <nav className="topnav" aria-label="Portal navigation">
      <a className="topnav__link" href="/" aria-current="page">
        <CalendarDays size={15} strokeWidth={1.5} aria-hidden="true" />
        <span>Event Booking Portal</span>
      </a>
      <span className="topnav__divider" aria-hidden="true" />
      <a className="topnav__link" href="https://www.bahrauniversity.edu.in" target="_blank" rel="noopener noreferrer">
        <span>Back to Website</span>
        <ArrowRight size={14} strokeWidth={1.5} aria-hidden="true" />
      </a>
    </nav>
  )
}
