import { useState } from 'react'

// Drop the official logo at public/images/logo.png to use it automatically.
// Until then, a typographic recreation of the wordmark is shown.
export default function UniversityBrand() {
  const [hasLogo, setHasLogo] = useState(true)

  return (
    <a className="brand" href="/" aria-label="Bahra University - Aspirations to Reality">
      {hasLogo ? (
        <img
          className="brand__img"
          src="/images/logo.png"
          alt="Bahra University - Aspirations to Reality"
          onError={() => setHasLogo(false)}
        />
      ) : (
        <span className="brand__text">
          <span className="brand__name">
            B<span className="brand__mark" aria-hidden="true" />HRA
          </span>
          <span className="brand__uni">UNIVERSITY</span>
          <span className="brand__tag">ASPIRATIONS TO REALITY</span>
        </span>
      )}
    </a>
  )
}
